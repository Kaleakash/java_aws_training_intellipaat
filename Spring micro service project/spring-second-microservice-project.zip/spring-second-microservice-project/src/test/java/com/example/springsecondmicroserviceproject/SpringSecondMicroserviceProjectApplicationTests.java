package com.example.springsecondmicroserviceproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecondMicroserviceProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
